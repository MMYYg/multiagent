
outx1=out.x1.Data;
outx2=out.x2.Data;
outx3=out.x3.Data;
outx4=out.x4.Data;
outx5=out.x5.Data;
outy1=out.y1.Data;
outy2=out.y2.Data;
outy3=out.y3.Data;
outy4=out.y4.Data;
outy5=out.y5.Data;
chang=length(outx1);
%central part
% '+'  Plus sign
% 'o'  Circle
% '*'  Asterisk
% '.'  Point
% 'x'  Cross
figure(2)
%% p1 wujiaoixng
plot(out.x1.Data(1),out.y1.Data(1),'p','Color','r','MarkerSize',11);
hold on
%% p2 yuanquan O
plot(out.x2.Data(1),out.y2.Data(1),'o','Color','r');
hold on
%% p3
plot(out.x3.Data(1),out.y3.Data(1),'*','Color','r');
hold on
%% p4
plot(out.x4.Data(1),out.y4.Data(1),'s','Color','r');
hold on
%% p5
plot(out.x5.Data(1),out.y5.Data(1),'v','Color','r');
hold on
% central point
xc=(outx1(chang)+ outx2(chang) +outx3(chang)+ outx5(chang)+outx4(chang))/5;
yc=(outy1(chang)+ outy2(chang) +outy3(chang)+ outy5(chang)+outy4(chang))/5;
plot(xc,yc,'.','Color','r','MarkerSize',30);
hold on
%% final position
plot(out.x1.Data(chang),out.y1.Data(chang),'p','Color','r','MarkerSize',11);
plot(out.x2.Data(chang),out.y2.Data(chang),'o','Color','r');
plot(out.x3.Data(chang),out.y3.Data(chang),'*','Color','r');
plot(out.x4.Data(chang),out.y4.Data(chang),'s','Color','r');
plot(out.x5.Data(chang),out.y5.Data(chang),'v','Color','r');
% legend('p1','p2','p3','p4','p5','centriod');
x = [outx1(chang) outx2(chang) outx3(chang)    outx4(chang) outx5(chang) outx1(chang)];
y = [outy1(chang) outy2(chang) outy3(chang)    outy4(chang) outy5(chang) outy1(chang)] ;
plot(outx1,outy1,'b');
% hold on;
plot(outx2,outy2,'b');
% hold on;
plot(outx3,outy3,'b');
% hold on;
plot(outx4,outy4,'b');
% hold on;
plot(outx5,outy5,'b');
% hold on;
plot(x,y,'--');
hold off;
xlabel('x');
ylabel('y');
legend('Agent1','Agent2','Agent3','Agent4','Agent5','Centroid')
% distance1=(outx1(chang)-outx2(chang))^2+(outy1(chang)-outy2(chang))^2
% distance2=(outx3(chang)-outx2(chang))^2+(outy3(chang)-outy2(chang))^2
% distance3=(outx3(chang)-outx5(chang))^2+(outy3(chang)-outy5(chang))^2
% distance4=(outx4(chang)-outx5(chang))^2+(outy4(chang)-outy5(chang))^2
% distance5=(outx1(chang)-outx4(chang))^2+(outy1(chang)-outy4(chang))^2
distance1=(outx1(chang)-outx2(chang))^2+(outy1(chang)-outy2(chang))^2
distance2=(outx3(chang)-outx2(chang))^2+(outy3(chang)-outy2(chang))^2
distance3=(outx3(chang)-outx4(chang))^2+(outy3(chang)-outy4(chang))^2
distance4=(outx4(chang)-outx5(chang))^2+(outy4(chang)-outy5(chang))^2
distance5=(outx1(chang)-outx5(chang))^2+(outy1(chang)-outy5(chang))^2
% p1=[];
% for i =1: chang
%     l=[outx1(i);outy1(i)];
%     p1=[p1,l];
% end
% figure(5)
% 
%  plot(p1);
% % plot(out.x1.Data,'DisplayName','x_1');
% % plot(out.x2.Data,'DisplayName','x_1');
% % plot(out.x3.Data,'DisplayName','x_1');
% % plot(out.x4.Data,'DisplayName','x_1');
% hold on;
% % plot(out.y2.Data,'DisplayName','x_2');
% % plot(out.y3.Data,'DisplayName','x_3');
% % plot(out.y4.Data,'DisplayName','x_4');
% % plot(out.y5.Data,'DisplayName','x_5');
% xlabel('Time');
% ylabel('x_i,i=1,2,3,4,5' );
% legend show;
% grid on;