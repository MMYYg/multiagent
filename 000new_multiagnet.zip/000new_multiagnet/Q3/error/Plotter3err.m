close all
figure(3)
plot(out.x1.Time,out.x1.Data,'g','DisplayName','x_1 : leader','linewidth',2);
hold on;
plot(out.x2.Time,out.x2.Data,'--','Color','r','DisplayName','x_2 : Follower','linewidth',2);
hold on;
plot(out.x3.Time,out.x3.Data,':','Color','k','DisplayName','x_3 : Follower','linewidth',2);
hold on;
plot(out.x4.Time,out.x4.Data,'b','DisplayName','x_4 : Follower','linewidth',2);
xlabel('Time');
ylabel('x_i,i=1,2,3,4' );
legend show;
grid on;
figure(33)
plot(out.err2.Time,out.err2.Data,'--','Color','r','DisplayName','error_2','linewidth',2);
hold on
plot(out.err3.Time,out.err3.Data,':','Color','k','DisplayName','error_3','linewidth',2);
hold on
plot(out.err4.Time,out.err4.Data,'DisplayName','error_4','linewidth',2);
xlabel('Time');
ylabel('error_i,i=1,2,3,4' );
legend show;
grid on;