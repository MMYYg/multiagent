close all
figure(1)
plot(out.x1.Time,out.x1.Data,'DisplayName','x_1');
hold on;
plot(out.x2.Time,out.x2.Data,'DisplayName','x_2');
plot(out.x3.Time,out.x3.Data,'DisplayName','x_3');
plot(out.x4.Time,out.x4.Data,'DisplayName','x_4');
plot(out.x5.Time,out.x5.Data,'DisplayName','x_5');
plot(out.x6.Time,out.x6.Data,'DisplayName','x_6');
plot(out.x7.Time,out.x7.Data,'DisplayName','x_7');
plot(out.x8.Time,out.x8.Data,'DisplayName','x_8');
plot(out.x9.Time,out.x9.Data,'DisplayName','x_9');
xlabel('Time');
ylabel('x_i,i=1,2,3,4,5,6,7,8,9' );
legend show;
grid on;
a=length(out.x1.Data);
[out.x1.Data(a) out.x2.Data(a) out.x3.Data(a) out.x4.Data(a) out.x5.Data(a) out.x6.Data(a) out.x7.Data(a) out.x8.Data(a) out.x9.Data(a)]