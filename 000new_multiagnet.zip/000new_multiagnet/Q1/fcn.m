% function [x1dot,x2dot,x3dot,x4dot] = fcn(x1,x2,x3,x4)
% x1dot=0;
% k=2;
% x2dot = k*(x1-x2);
% x3dot = k*(x1-x3);
% x4dot = k*(x2+x3-2*x4);
% end
function [x1dot,x2dot,x3dot,x4dot,x5dot,y1dot,y2dot,y3dot,y4dot,y5dot] = fcn(x1,x2,x3,x4,x5,y1,y2,y3,y4,y5)

p1=[x1,y1];
p2=[x2,y2];
p3=[x3,y3];
p4=[x4,y4];
p5=[x5,y5];

d41=[-1,0];
d12=[-1,1];
d23=[1,1];
d35=[1,-1];
d54=[-1,-1];
v=[1,1];

k=1;
p1dot = k*(p4+p2-d12+d41-2*p1+v);
p2dot = k*(p1+p3+d12-d23-2*p2+v);
p3dot = k*(p2+p5+d23-d35-2*p3+v);
p4dot = k*(p1+p5-d41+d54-2*p4+v);
p5dot = k*(p3+p4-d54+d35-2*p5+v);

x1dot=p1dot(1);
x2dot=p2dot(1);
x3dot=p3dot(1);
x4dot=p4dot(1);
x5dot=p5dot(1);
y1dot=p1dot(2);
y2dot=p2dot(2);
y3dot=p3dot(2);
y4dot=p4dot(2);
y5dot=p5dot(2);
end