#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "Q1_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "Q1.h"
#include "Q1_capi.h"
#include "Q1_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 1 , TARGET_STRING (
"Q1/MATLAB Function" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 1 , 1
, TARGET_STRING ( "Q1/MATLAB Function" ) , TARGET_STRING ( "" ) , 1 , 0 , 0 ,
0 , 0 } , { 2 , 1 , TARGET_STRING ( "Q1/MATLAB Function" ) , TARGET_STRING (
"" ) , 2 , 0 , 0 , 0 , 0 } , { 3 , 1 , TARGET_STRING ( "Q1/MATLAB Function" )
, TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0 } , { 4 , 1 , TARGET_STRING (
"Q1/MATLAB Function" ) , TARGET_STRING ( "" ) , 4 , 0 , 0 , 0 , 0 } , { 5 , 1
, TARGET_STRING ( "Q1/MATLAB Function" ) , TARGET_STRING ( "" ) , 5 , 0 , 0 ,
0 , 0 } , { 6 , 1 , TARGET_STRING ( "Q1/MATLAB Function" ) , TARGET_STRING (
"" ) , 6 , 0 , 0 , 0 , 0 } , { 7 , 1 , TARGET_STRING ( "Q1/MATLAB Function" )
, TARGET_STRING ( "" ) , 7 , 0 , 0 , 0 , 0 } , { 8 , 1 , TARGET_STRING (
"Q1/MATLAB Function" ) , TARGET_STRING ( "" ) , 8 , 0 , 0 , 0 , 0 } , { 9 , 0
, TARGET_STRING ( "Q1/Integrator" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
0 } , { 10 , 0 , TARGET_STRING ( "Q1/Integrator1" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 11 , 0 , TARGET_STRING ( "Q1/Integrator2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 12 , 0 , TARGET_STRING (
"Q1/Integrator3" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 13 , 0 ,
TARGET_STRING ( "Q1/Integrator4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0
} , { 14 , 0 , TARGET_STRING ( "Q1/Integrator5" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 15 , 0 , TARGET_STRING ( "Q1/Integrator6" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 16 , 0 , TARGET_STRING (
"Q1/Integrator7" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 17 , 0 ,
TARGET_STRING ( "Q1/Integrator8" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0
} , { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_BlockParameters rtBlockParameters [ ] = { { 18 , TARGET_STRING (
"Q1/Integrator" ) , TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 19
, TARGET_STRING ( "Q1/Integrator1" ) , TARGET_STRING ( "InitialCondition" ) ,
0 , 0 , 0 } , { 20 , TARGET_STRING ( "Q1/Integrator2" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 21 , TARGET_STRING ( "Q1/Integrator3"
) , TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 22 , TARGET_STRING
( "Q1/Integrator4" ) , TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , {
23 , TARGET_STRING ( "Q1/Integrator5" ) , TARGET_STRING ( "InitialCondition"
) , 0 , 0 , 0 } , { 24 , TARGET_STRING ( "Q1/Integrator6" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 25 , TARGET_STRING ( "Q1/Integrator7"
) , TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 26 , TARGET_STRING
( "Q1/Integrator8" ) , TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , {
0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 } } ; static int_T rt_LoggedStateIdxList
[ ] = { - 1 } ; static const rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , (
NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_Signals
rtRootOutputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ;
static const rtwCAPI_ModelParameters rtModelParameters [ ] = { { 0 , ( NULL )
, 0 , 0 , 0 } } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . co21ovagrh , & rtB . ifccvx1xoj ,
& rtB . hez3cgytm2 , & rtB . bkayd04auv , & rtB . kwwi4vgnvo , & rtB .
do1u3qnlfl , & rtB . bb54vouobd , & rtB . fkfr5iewfi , & rtB . pfjiaqpogc , &
rtB . bgh4rcjfjz , & rtB . etslqymx2k , & rtB . aenpn3s1or , & rtB .
m3y0ofkz3u , & rtB . jlnkrgxfui , & rtB . gmt0lcnszj , & rtB . herjjtu3y1 , &
rtB . mqpdg2j04z , & rtB . iqen5w1pqq , & rtP . Integrator_IC , & rtP .
Integrator1_IC , & rtP . Integrator2_IC , & rtP . Integrator3_IC , & rtP .
Integrator4_IC , & rtP . Integrator5_IC , & rtP . Integrator6_IC , & rtP .
Integrator7_IC , & rtP . Integrator8_IC , } ; static int32_T *
rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } } ; static const uint_T rtDimensionArray [ ] = {
1 , 1 } ; static const real_T rtcapiStoredFloats [ ] = { 0.0 } ; static const
rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static const rtwCAPI_SampleTimeMap
rtSampleTimeMap [ ] = { { ( const void * ) & rtcapiStoredFloats [ 0 ] , (
const void * ) & rtcapiStoredFloats [ 0 ] , 0 , 0 } } ; static
rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 18 ,
rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 9 ,
rtModelParameters , 0 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 2722334673U , 2360938898U , 2715714943U , 3086362900U } , ( NULL ) , 0 ,
0 , rt_LoggedStateIdxList } ; const rtwCAPI_ModelMappingStaticInfo *
Q1_GetCAPIStaticMap ( void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void Q1_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion ( ( *
rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void Q1_host_InitializeDataMapInfo ( Q1_host_DataMapInfo_T * dataMap , const
char * path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ;
rtwCAPI_SetStaticMap ( dataMap -> mmi , & mmiStatic ) ;
rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
