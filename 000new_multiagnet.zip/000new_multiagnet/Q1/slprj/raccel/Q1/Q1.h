#ifndef RTW_HEADER_Q1_h_
#define RTW_HEADER_Q1_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap_simtarget.h"
#ifndef Q1_COMMON_INCLUDES_
#define Q1_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "Q1_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#define MODEL_NAME Q1
#define NSAMPLE_TIMES (1) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (18) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (9)   
#elif NCSTATES != 9
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T bgh4rcjfjz ; real_T etslqymx2k ; real_T aenpn3s1or ;
real_T m3y0ofkz3u ; real_T jlnkrgxfui ; real_T gmt0lcnszj ; real_T herjjtu3y1
; real_T mqpdg2j04z ; real_T iqen5w1pqq ; real_T co21ovagrh ; real_T
ifccvx1xoj ; real_T hez3cgytm2 ; real_T bkayd04auv ; real_T kwwi4vgnvo ;
real_T do1u3qnlfl ; real_T bb54vouobd ; real_T fkfr5iewfi ; real_T pfjiaqpogc
; } B ; typedef struct { real_T hqan25lkl3 ; real_T gu2pt0bovv ; real_T
igfcjwrejv ; real_T hwp5vguixz ; real_T kovudp5dq5 ; real_T eo0hpkjr23 ;
real_T lvotmysvvv ; real_T naicksbugg ; real_T aacvgfiq3q ; } X ; typedef
struct { real_T hqan25lkl3 ; real_T gu2pt0bovv ; real_T igfcjwrejv ; real_T
hwp5vguixz ; real_T kovudp5dq5 ; real_T eo0hpkjr23 ; real_T lvotmysvvv ;
real_T naicksbugg ; real_T aacvgfiq3q ; } XDot ; typedef struct { boolean_T
hqan25lkl3 ; boolean_T gu2pt0bovv ; boolean_T igfcjwrejv ; boolean_T
hwp5vguixz ; boolean_T kovudp5dq5 ; boolean_T eo0hpkjr23 ; boolean_T
lvotmysvvv ; boolean_T naicksbugg ; boolean_T aacvgfiq3q ; } XDis ; typedef
struct { real_T hqan25lkl3 ; real_T gu2pt0bovv ; real_T igfcjwrejv ; real_T
hwp5vguixz ; real_T kovudp5dq5 ; real_T eo0hpkjr23 ; real_T lvotmysvvv ;
real_T naicksbugg ; real_T aacvgfiq3q ; } CStateAbsTol ; typedef struct {
real_T hqan25lkl3 ; real_T gu2pt0bovv ; real_T igfcjwrejv ; real_T hwp5vguixz
; real_T kovudp5dq5 ; real_T eo0hpkjr23 ; real_T lvotmysvvv ; real_T
naicksbugg ; real_T aacvgfiq3q ; } CXPtMin ; typedef struct { real_T
hqan25lkl3 ; real_T gu2pt0bovv ; real_T igfcjwrejv ; real_T hwp5vguixz ;
real_T kovudp5dq5 ; real_T eo0hpkjr23 ; real_T lvotmysvvv ; real_T naicksbugg
; real_T aacvgfiq3q ; } CXPtMax ; typedef struct { rtwCAPI_ModelMappingInfo
mmi ; } DataMapInfo ; struct P_ { real_T Integrator_IC ; real_T
Integrator1_IC ; real_T Integrator2_IC ; real_T Integrator3_IC ; real_T
Integrator4_IC ; real_T Integrator5_IC ; real_T Integrator6_IC ; real_T
Integrator7_IC ; real_T Integrator8_IC ; } ; extern const char *
RT_MEMORY_ALLOCATION_ERROR ; extern B rtB ; extern X rtX ; extern P rtP ;
extern mxArray * mr_Q1_GetDWork ( ) ; extern void mr_Q1_SetDWork ( const
mxArray * ssDW ) ; extern mxArray * mr_Q1_GetSimStateDisallowedBlocks ( ) ;
extern const rtwCAPI_ModelMappingStaticInfo * Q1_GetCAPIStaticMap ( void ) ;
extern SimStruct * const rtS ; extern const int_T gblNumToFiles ; extern
const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ; extern
rtInportTUtable * gblInportTUtables ; extern const char * gblInportFileName ;
extern const int_T gblNumRootInportBlks ; extern const int_T
gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ; extern
const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [ ] ;
extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
