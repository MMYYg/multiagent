#include "Q1.h"
#include "Q1_private.h"
P rtP = { 2.0 , 2.0 , 3.0 , 4.0 , 5.0 , 6.0 , 7.0 , 8.0 , 9.0 } ;
