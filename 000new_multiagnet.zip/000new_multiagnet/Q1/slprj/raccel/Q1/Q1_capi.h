#ifndef RTW_HEADER_Q1_capi_h
#define RTW_HEADER_Q1_capi_h
#include "Q1.h"
extern void Q1_InitializeDataMapInfo ( void ) ;
#endif
