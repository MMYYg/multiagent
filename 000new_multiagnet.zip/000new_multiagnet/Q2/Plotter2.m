close all
figure(1)
plot(out.x1.Time,out.x1.Data,'DisplayName','x_1:leader');
hold on;
plot(out.x2.Time,out.x2.Data,'DisplayName','x_2');
plot(out.x3.Time,out.x3.Data,'DisplayName','x_3');
plot(out.x4.Time,out.x4.Data,'DisplayName','x_4');
plot(out.x5.Time,out.x5.Data,'DisplayName','x_5');
xlabel('Time');
ylabel('x_i,i=1,2,3,4,5' );
legend show;
grid on;
a=length(out.x1.Data);
[out.x1.Data(a) out.x2.Data(a) out.x3.Data(a) out.x4.Data(a) out.x5.Data(a)]